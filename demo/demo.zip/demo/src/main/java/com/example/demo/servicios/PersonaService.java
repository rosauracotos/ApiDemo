package com.example.demo.servicios;

import com.example.demo.entidades.Persona;

public interface PersonaService extends BaseService<Persona, Long>{
}

