package com.example.demo.servicios;

import com.example.demo.entidades.Alumno;

public interface AlumnoService extends BaseService<Alumno, Long>{
}
