package com.example.demo.servicios;

import com.example.demo.entidades.Autor;

public interface AutorService extends BaseService<Autor, Long> {

}
